import React from 'react'
import './footer.css'
const Footer = () => {
  return (
  <section className="footer">
    <span>
      Developed by Shahzaib Aftab 2023 | All Rights reserved.
    </span>
  </section>
  )
} 

export default Footer