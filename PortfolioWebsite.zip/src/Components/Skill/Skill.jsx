import React from "react";
import { TbBrandReact } from "react-icons/tb";
import { IoLogoJavascript } from "react-icons/io";
import { IoLogoSass } from "react-icons/io";
import { IoLogoCss3 } from "react-icons/io";
import { DiPhp } from "react-icons/di";
import { SiHtml5 } from "react-icons/si";
import "./skill.css";
const Skill = () => { 
  return (
    <section className="skills container section">
      <div className="sectionTitle">
        <span className="titleNumber">02.</span>
        <h5 className="titleText">
          Skills
          <div className="underline">
            <span></span>
          </div>
        </h5>
      </div>

      {/* skill container */}
      <div className="skillsContainer grid">
        {/* Single Group of skills */}
        <div className="skillGroup">
          <div className="groupTitle">
            <h2 className="title"> Web Development</h2>
            <span className="subTitle">2 Years Experience</span>
          </div>
          <div className="generalSkills">
            {/* single skill div */}
            <div className="singleSkill">
              <div className="iconBox flex">
                <TbBrandReact className="icon" />
              </div>
              <span className="skillName">React</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <IoLogoJavascript className="icon" />
              </div>
              <span className="skillName">Javascript</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <IoLogoSass className="icon" />
              </div>
              <span className="skillName">SASS</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <IoLogoCss3 className="icon" />
              </div>
              <span className="skillName">CSS3</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <SiHtml5 className="icon" />
              </div>
              <span className="skillName">HTML5</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <DiPhp className="icon" />
              </div>
              <span className="skillName">PHP</span>
            </div>
          </div>
        </div>
     

      
      {/* skill container */}
  
        {/* Single Group of skills */}
        <div className="skillGroup">
          <div className="groupTitle">
            <h2 className="title"> Web Development</h2>
            <span className="subTitle">2 Years Experience</span>
          </div>
          <div className="generalSkills">
            {/* single skill div */}
            <div className="singleSkill">
              <div className="iconBox flex">
                <TbBrandReact className="icon" />
              </div>
              <span className="skillName">React</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <IoLogoJavascript className="icon" />
              </div>
              <span className="skillName">Javascript</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <IoLogoSass className="icon" />
              </div>
              <span className="skillName">SASS</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <IoLogoCss3 className="icon" />
              </div>
              <span className="skillName">CSS3</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <SiHtml5 className="icon" />
              </div>
              <span className="skillName">HTML5</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <DiPhp className="icon" />
              </div>
              <span className="skillName">PHP</span>
            </div>
          </div>
        </div>
  
      {/* skill container */}
          {/* Single Group of skills */}
        <div className="skillGroup">
          <div className="groupTitle">
            <h2 className="title"> Web Development</h2>
            <span className="subTitle">2 Years Experience</span>
          </div>
          <div className="generalSkills">
            {/* single skill div */}
            <div className="singleSkill">
              <div className="iconBox flex">
                <TbBrandReact className="icon" />
              </div>
              <span className="skillName">React</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <IoLogoJavascript className="icon" />
              </div>
              <span className="skillName">Javascript</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <IoLogoSass className="icon" />
              </div>
              <span className="skillName">SASS</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <IoLogoCss3 className="icon" />
              </div>
              <span className="skillName">CSS3</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <SiHtml5 className="icon" />
              </div>
              <span className="skillName">HTML5</span>
            </div>

            <div className="singleSkill">
              <div className="iconBox flex">
                <DiPhp className="icon" />
              </div>
              <span className="skillName">PHP</span>
            </div>
          </div>
        </div>
        </div>  

    </section>
  );
};
//////OTHER SKILLS MYSQL Wordpress
export default Skill;
